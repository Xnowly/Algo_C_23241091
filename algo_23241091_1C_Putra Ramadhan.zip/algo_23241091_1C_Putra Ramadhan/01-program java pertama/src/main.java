public class main {
    public static void main(String[] args) {
        //Membuat aplikasi Biodata
        //Deklarasi Variabel dan Tipe data
        String nama;
        String nim;
        String prodi;
        String tgl_lahir;
        float tinggi_badan;
        double berat_badan;
        boolean status; // jika menikah = TRUE , Belum menikah = FALSE
        
        //Mengisi nilai dalam variabel 
        nama = "Putra Ramadhan";
        nim = "23241091";
        prodi = "Tekologi Informasi";
        tgl_lahir = "11-11-2004";
        tinggi_badan = 169f;
        berat_badan = 59d;
        status = false;

        System.out.println("============================");
        System.out.println("Nama mahasiswa : " + nama );
        System.out.println("NIM : " + nim);
        System.out.println("prodi" + prodi);
        System.out.println("Tanggal lahir" + tgl_lahir);
        System.out.println("Berat Badan" + berat_badan );
        System.out.println("Status" + status);
        System.out.println("============================");

    }
}
