import java.util.Scanner;

class Main {
    public static void main(String args[]) {
        // Data Member
        int total_belanja = 0;

        // Membuat objek scanner baru
        Scanner input = new Scanner(System.in);

        // Mengambil input
        System.out.print("Masukkan Total Belanja: ");
        total_belanja = input.nextInt();

        // Cek apakah total belanja di atas 50000
        if (total_belanja >= 50000) {
            System.out.println("Selamat Anda Dapat Mouse");
        } else {
            System.out.println("Belanja Anda kurang dari Rp.50.000");
        }

        System.out.println("Terima kasih");
    }
}