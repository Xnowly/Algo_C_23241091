import java.util.Scanner;

class KonversiNilai {
    public static void main(String args[]) {
        // Data Number
        int nilai;
        String grade;
        
        // Membuat objek scanner baru
        Scanner input = new Scanner(System.in); // Perbaikan penulisan "Scanner" dan "System"

        System.out.print("Masukan Nilai : "); // Perbaikan penulisan "System.out"
        nilai = input.nextInt();
        
        // Konversi nilai
        if (nilai >= 80) {
            grade = "A";
        } else if (nilai >= 70 && nilai <= 79) {
            grade = "B";
        } else if (nilai >= 60 && nilai <= 69) {
            grade = "C";
        } else if (nilai >= 50 && nilai <= 59) {
            grade = "D";
        } else {
            grade = "E";
        }
        
        System.out.println("Nilai Angka : " + nilai); // Perbaikan penulisan "System.out"
        System.out.println("Nilai Huruf : " + grade); // Perbaikan penulisan "System.out"
    }
}